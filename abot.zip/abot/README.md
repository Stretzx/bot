


# SC Kayzen Offc
### Kontak WA +6289635946324

# Berikut Setup untuk Project Ini
### Buka aplikasi Replit
### Pilih Create 
### Kolom Pencarian ketik Blank Repl
### Klik 3bar button sebelah pojok kiri bawah kemudian di bagian sidebar Files klik Titik 3 dan pilih Upload
### Upload satu persatu file riru.zip , replit.nix dan .replit
### Extract File riru.zip, caranya dengan masuk ke console ketik unzip riru.zip
### Install modul dengan cara ketik npm i
### Edit File setting .js
### Pencet tombol play pada replit
### Masuk ke tab webview dan Scan QR nya mengunakan Wa
### Bot siap digunakan
### Ketik ON pada grup untuk mengaktifkan Bot








